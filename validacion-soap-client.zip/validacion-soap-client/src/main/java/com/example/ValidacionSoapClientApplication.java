package com.example;

import com.example.consumingwebservice.ValidarClient;
import com.example.consumingwebservice.AppContextConfiguration;
import com.example.StatusResponse;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class ValidacionSoapClientApplication {

	public static void main(String[] args) {
        AnnotationConfigApplicationContext context =
                new AnnotationConfigApplicationContext(AppContextConfiguration.class);

        ValidarClient client = context.getBean(ValidarClient.class);

        // Llamar al servicio
        StatusResponse response = client.validarUsuario("admin", "1234");

        System.out.println("Validación exitosa: " + response.isValidate());
        System.out.println("Perfil: " + (response.getPerfil() != null ? response.getPerfil().toString() : "N/A"));
        System.out.println("Expira: " + response.getExpire());

        context.close();
    }
}
