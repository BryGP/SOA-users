package com.example.consumingwebservice;

import com.example.ValidarPortType;
import com.example.StatusResponse;
import com.example.ValidarSOAPService;
import jakarta.xml.ws.Holder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;

@Component
public class ValidarClient 
{
	private final Jaxb2Marshaller marshaller;

    @Autowired
    public ValidarClient(Jaxb2Marshaller marshaller) {
        this.marshaller = marshaller;
    }

    public StatusResponse validarUsuario(String usuario, String password) {
        // Crear el servicio y el puerto
        ValidarSOAPService service = new ValidarSOAPService();
        ValidarPortType port = service.getValidarPort();

        // Crear Holders para los parámetros de salida
        Holder<Boolean> validate = new Holder<>();
        Holder<StatusResponse.Perfil> perfil = new Holder<>();
        Holder<String> expire = new Holder<>();

        // Invocar el servicio
        port.validarRequest(usuario, password, validate, perfil, expire);

        // Crear y devolver el objeto StatusResponse con la información recibida
        StatusResponse response = new StatusResponse();
        response.setValidate(validate.value);
        response.setPerfil(perfil.value);
        response.setExpire(expire.value);

        return response;
    }
}
