package com.example.consumingwebservice;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class AppContextConfiguration 
{
	@Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // Indicar el package donde se generaron las clases del WSDL
        marshaller.setContextPath("com.example");
        return marshaller;
    }
	
	@Bean
    public ValidarClient validarClient(Jaxb2Marshaller marshaller) {
        return new ValidarClient(marshaller);
    }
}
