package com.example.soap;

import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.example.business.Validacion;
import com.example.ValidarRequest;
import com.example.StatusResponse;

@Endpoint
public class ValidacionEndpoint 
{
    private static final String NAMESPACE_URI = "http://com.example/";
    private final Validacion validacion;

    public ValidacionEndpoint(Validacion validacion) {
        this.validacion = validacion;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "ValidarRequest")
    @ResponsePayload
    public StatusResponse validar(@RequestPayload ValidarRequest request) {
        return validacion.validar(request.getUsername(), request.getPassword());
    }
}
