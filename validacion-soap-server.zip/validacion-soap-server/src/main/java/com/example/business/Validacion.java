package com.example.business;

import org.springframework.stereotype.Service;
import com.example.StatusResponse;

@Service
public class Validacion 
{
	public StatusResponse validar(String username, String password) {
        StatusResponse response = new StatusResponse();

        if ("admin".equals(username) && "1234".equals(password)) {
            response.setValidate(true);

            StatusResponse.Perfil perfil = new StatusResponse.Perfil();
            perfil.setNombre("Administrador del Sistema");
            perfil.setTelefono("4421234567");
            perfil.setCorreo("admin@example.com");

            response.setPerfil(perfil);
            response.setExpire("2025-12-31");
        } else {
            response.setValidate(false);
            StatusResponse.Perfil perfil = new StatusResponse.Perfil();
            perfil.setNombre("No autorizado");
            perfil.setTelefono("N/A");
            perfil.setCorreo("N/A");
            response.setPerfil(perfil);
            response.setExpire("N/A");
        }

        return response;
    }
}
